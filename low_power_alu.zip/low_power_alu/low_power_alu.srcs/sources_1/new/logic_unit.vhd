library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.alu_pkg.ALL;

entity logic_unit is
    Port (
        op_sel  : in  std_logic_vector(OP_WIDTH-1 downto 0);
        in_A    : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        in_B    : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        log_out : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end logic_unit;

architecture Behavioral of logic_unit is
begin
    process(op_sel, in_A, in_B)
    begin
        log_out <= (others => '0');
        
        case op_sel is
            when OP_AND => 
                log_out <= in_A and in_B;
                
            when OP_OR => 
                log_out <= in_A or in_B;
                
            when OP_XOR => 
                log_out <= in_A xor in_B;
                
            when OP_NOT => 
                log_out <= not in_A;
                
            when others => 
                null;
        end case;
    end process;
end Behavioral;