library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity shift_unit is
    Port (
        op_sel    : in  std_logic_vector(OP_WIDTH-1 downto 0);
        in_A      : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        in_B      : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        shift_out : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end shift_unit;

architecture Behavioral of shift_unit is
begin
    process(op_sel, in_A, in_B)
        variable shamt : integer range 0 to 31;
    begin
        shift_out <= (others => '0');
        shamt := to_integer(unsigned(in_B(4 downto 0)));
        
        case op_sel is
            when OP_SLL => 
                shift_out <= std_logic_vector(shift_left(unsigned(in_A), shamt));
                
            when OP_SRL => 
                shift_out <= std_logic_vector(shift_right(unsigned(in_A), shamt));
                
            when OP_SRA => 
                shift_out <= std_logic_vector(shift_right(signed(in_A), shamt));
                
            when OP_ROR => 
                shift_out <= std_logic_vector(rotate_right(unsigned(in_A), shamt));
                
            when others => 
                null;
        end case;
    end process;
end Behavioral;