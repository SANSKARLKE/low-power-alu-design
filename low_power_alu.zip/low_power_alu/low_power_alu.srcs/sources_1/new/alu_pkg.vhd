library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

package alu_pkg is
    constant DATA_WIDTH : integer := 32;
    constant OP_WIDTH   : integer := 4;
    constant FLAG_WIDTH : integer := 8;
    constant OP_ADD  : std_logic_vector(OP_WIDTH-1 downto 0) := "0000";
    constant OP_SUB  : std_logic_vector(OP_WIDTH-1 downto 0) := "0001";
    constant OP_MUL  : std_logic_vector(OP_WIDTH-1 downto 0) := "0010";
    constant OP_INC  : std_logic_vector(OP_WIDTH-1 downto 0) := "0011";
    constant OP_AND  : std_logic_vector(OP_WIDTH-1 downto 0) := "0100";
    constant OP_OR   : std_logic_vector(OP_WIDTH-1 downto 0) := "0101";
    constant OP_XOR  : std_logic_vector(OP_WIDTH-1 downto 0) := "0110";
    constant OP_NOT  : std_logic_vector(OP_WIDTH-1 downto 0) := "0111";
    constant OP_SLL  : std_logic_vector(OP_WIDTH-1 downto 0) := "1000";
    constant OP_SRL  : std_logic_vector(OP_WIDTH-1 downto 0) := "1001";
    constant OP_SRA  : std_logic_vector(OP_WIDTH-1 downto 0) := "1010";
    constant OP_ROR  : std_logic_vector(OP_WIDTH-1 downto 0) := "1011";
    constant OP_SLT  : std_logic_vector(OP_WIDTH-1 downto 0) := "1100";
    constant OP_SLTU : std_logic_vector(OP_WIDTH-1 downto 0) := "1101";
    constant OP_SEQ  : std_logic_vector(OP_WIDTH-1 downto 0) := "1110";
    constant OP_SNE  : std_logic_vector(OP_WIDTH-1 downto 0) := "1111";
    constant FLAG_Z  : integer := 0;
    constant FLAG_N  : integer := 1;
    constant FLAG_C  : integer := 2;
    constant FLAG_V  : integer := 3; 
    constant FLAG_P  : integer := 4;

end alu_pkg;

package body alu_pkg is
end alu_pkg;