library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity top_alu is
    Port (
        clk       : in  std_logic;
        rst       : in  std_logic;
        opcode    : in  std_logic_vector(OP_WIDTH-1 downto 0);
        src_A     : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        src_B     : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        alu_out   : out std_logic_vector(DATA_WIDTH-1 downto 0);
        alu_flags : out std_logic_vector(FLAG_WIDTH-1 downto 0)
    );
end top_alu;

architecture Structural of top_alu is
    signal reg_A, reg_B : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal reg_op       : std_logic_vector(OP_WIDTH-1 downto 0)   := (others => '0');
    signal gate_A_arith, gate_B_arith : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal gate_A_logic, gate_B_logic : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal gate_A_shift, gate_B_shift : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal out_arith : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal out_logic : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal out_shift : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal carry_arith, over_arith : std_logic;
    signal res_mux            : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal flags_comb         : std_logic_vector(FLAG_WIDTH-1 downto 0) := (others => '0');
    signal reg_out            : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal reg_flags          : std_logic_vector(FLAG_WIDTH-1 downto 0) := (others => '0');
    signal flags_comb_updated : std_logic_vector(FLAG_WIDTH-1 downto 0);
    attribute keep_hierarchy : string;
    attribute keep_hierarchy of U_ARITH : label is "true";
    attribute keep_hierarchy of U_LOGIC : label is "true";
    attribute keep_hierarchy of U_SHIFT : label is "true";

begin
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                reg_A  <= (others => '0');
                reg_B  <= (others => '0');
                reg_op <= (others => '0');
            else
                reg_A  <= src_A;
                reg_B  <= src_B;
                reg_op <= opcode;
            end if;
        end if;
    end process;
    process(reg_op, reg_A, reg_B)
    begin
        gate_A_arith <= (others => '0'); gate_B_arith <= (others => '0');
        gate_A_logic <= (others => '0'); gate_B_logic <= (others => '0');
        gate_A_shift <= (others => '0'); gate_B_shift <= (others => '0');

        case reg_op is
            when OP_ADD | OP_SUB | OP_MUL | OP_INC =>
                gate_A_arith <= reg_A;
                gate_B_arith <= reg_B;
            when OP_AND | OP_OR | OP_XOR | OP_NOT =>
                gate_A_logic <= reg_A;
                gate_B_logic <= reg_B;
            when OP_SLL | OP_SRL | OP_SRA | OP_ROR =>
                gate_A_shift <= reg_A;
                gate_B_shift <= reg_B;
            when OP_SLT | OP_SLTU | OP_SEQ | OP_SNE =>
                gate_A_arith <= reg_A;
                gate_B_arith <= reg_B;

            when others => null;
        end case;
    end process;
    U_ARITH : entity work.arith_unit
        port map (op_sel => reg_op, in_A => gate_A_arith, in_B => gate_B_arith, arith_out => out_arith, carry_out => carry_arith, over_out => over_arith);

    U_LOGIC : entity work.logic_unit
        port map (op_sel => reg_op, in_A => gate_A_logic, in_B => gate_B_logic, log_out => out_logic);

    U_SHIFT : entity work.shift_unit
        port map (op_sel => reg_op, in_A => gate_A_shift, in_B => gate_B_shift, shift_out => out_shift);
    process(reg_op, out_arith, out_logic, out_shift, reg_A, reg_B, carry_arith, over_arith)
    begin
        res_mux    <= (others => '0');
        flags_comb <= (others => '0');

        case reg_op is
            when OP_ADD | OP_SUB | OP_MUL | OP_INC =>
                res_mux            <= out_arith;
                flags_comb(FLAG_C) <= carry_arith;
                flags_comb(FLAG_V) <= over_arith;

            when OP_AND | OP_OR | OP_XOR | OP_NOT =>
                res_mux <= out_logic;

            when OP_SLL | OP_SRL | OP_SRA | OP_ROR =>
                res_mux <= out_shift;
            when OP_SLT =>
                if signed(reg_A) < signed(reg_B) then
                    res_mux <= std_logic_vector(to_unsigned(1, DATA_WIDTH));
                end if;
            when OP_SLTU =>
                if unsigned(reg_A) < unsigned(reg_B) then
                    res_mux <= std_logic_vector(to_unsigned(1, DATA_WIDTH));
                end if;
            when OP_SEQ =>
                if reg_A = reg_B then
                    res_mux <= std_logic_vector(to_unsigned(1, DATA_WIDTH));
                end if;
            when OP_SNE =>
                if reg_A /= reg_B then
                    res_mux <= std_logic_vector(to_unsigned(1, DATA_WIDTH));
                end if;
            when others => null;
        end case;
    end process;
    process(res_mux, flags_comb)
        variable p_temp : std_logic;
    begin
        flags_comb_updated <= flags_comb;
        if res_mux = x"00000000" then
            flags_comb_updated(FLAG_Z) <= '1';
        else
            flags_comb_updated(FLAG_Z) <= '0';
        end if;
        flags_comb_updated(FLAG_N) <= res_mux(31);
        p_temp := '1';
        for i in 0 to 7 loop
            p_temp := p_temp xor res_mux(i);
        end loop;
        flags_comb_updated(FLAG_P) <= p_temp;
    end process;
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                reg_out   <= (others => '0');
                reg_flags <= (others => '0');
            else
                reg_out   <= res_mux;
                reg_flags <= flags_comb_updated;
            end if;
        end if;
    end process;

    alu_out   <= reg_out;
    alu_flags <= reg_flags;

end Structural;