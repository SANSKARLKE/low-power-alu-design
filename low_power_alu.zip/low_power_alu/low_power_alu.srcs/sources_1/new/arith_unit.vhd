library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity arith_unit is
    Port (
        op_sel    : in  std_logic_vector(OP_WIDTH-1 downto 0);
        in_A      : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        in_B      : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        arith_out : out std_logic_vector(DATA_WIDTH-1 downto 0);
        carry_out : out std_logic;
        over_out  : out std_logic
    );
end arith_unit;

architecture Behavioral of arith_unit is
begin
    process(op_sel, in_A, in_B)
        variable sum_ext : unsigned(DATA_WIDTH downto 0);
        variable sub_ext : unsigned(DATA_WIDTH downto 0);
        variable mul_ext : unsigned((DATA_WIDTH*2)-1 downto 0);
    begin
        arith_out <= (others => '0');
        carry_out <= '0';
        over_out  <= '0';

        case op_sel is
            when OP_ADD =>
                sum_ext   := unsigned('0' & in_A) + unsigned('0' & in_B);
                arith_out <= std_logic_vector(sum_ext(DATA_WIDTH-1 downto 0));
                carry_out <= sum_ext(DATA_WIDTH);
                if (in_A(31) = '0' and in_B(31) = '0' and sum_ext(31) = '1') or
                   (in_A(31) = '1' and in_B(31) = '1' and sum_ext(31) = '0') then
                    over_out <= '1';
                end if;

            when OP_SUB =>
                sub_ext   := unsigned('0' & in_A) - unsigned('0' & in_B);
                arith_out <= std_logic_vector(sub_ext(DATA_WIDTH-1 downto 0));
                carry_out <= sub_ext(DATA_WIDTH);
                if (in_A(31) = '0' and in_B(31) = '1' and sub_ext(31) = '1') or
                   (in_A(31) = '1' and in_B(31) = '0' and sub_ext(31) = '0') then
                    over_out <= '1';
                end if;

            when OP_MUL =>
                mul_ext   := unsigned(in_A) * unsigned(in_B);
                arith_out <= std_logic_vector(mul_ext(DATA_WIDTH-1 downto 0));

            when OP_INC =>
                arith_out <= std_logic_vector(unsigned(in_A) + 1);
                if in_A = x"FFFFFFFF" then
                    carry_out <= '1';
                end if;

            when others =>
                null;
        end case;
    end process;
end Behavioral;