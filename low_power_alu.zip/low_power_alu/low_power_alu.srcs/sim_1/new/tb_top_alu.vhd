library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity tb_top_alu is
end tb_top_alu;

architecture Behavioral of tb_top_alu is
    signal clk       : std_logic := '0';
    signal rst       : std_logic := '0';
    signal opcode    : std_logic_vector(OP_WIDTH-1 downto 0) := (others => '0');
    signal src_A     : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal src_B     : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal alu_out   : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal alu_flags : std_logic_vector(FLAG_WIDTH-1 downto 0);
    constant CLK_PERIOD : time := 20 ns; --edit this to change clock period

begin
    UUT: entity work.top_alu
        port map (
            clk       => clk,
            rst       => rst,
            opcode    => opcode,
            src_A     => src_A,
            src_B     => src_B,
            alu_out   => alu_out,
            alu_flags => alu_flags
        );
    clk_process : process
    begin
        clk <= '0';
        wait for CLK_PERIOD/2;
        clk <= '1';
        wait for CLK_PERIOD/2;
    end process;
    stim_proc: process
        variable var_A   : std_logic_vector(DATA_WIDTH-1 downto 0) := x"55555555";
        variable var_B   : std_logic_vector(DATA_WIDTH-1 downto 0) := x"AAAAAAAA"; 
        variable shift_c : unsigned(4 downto 0) := "00001"; 
    begin
        rst <= '1';
        opcode <= (others => '0');
        src_A  <= (others => '0');
        src_B  <= (others => '0');
        wait for CLK_PERIOD * 2;
        rst <= '0';
        wait for CLK_PERIOD;
        for loop_count in 1 to 10 loop
            for op_val in 0 to 15 loop
                var_A := not var_A;
                var_B := not var_B;
                shift_c := shift_c + 1;
                if shift_c = 0 then 
                    shift_c := "00001"; 
                end if;
                opcode <= std_logic_vector(to_unsigned(op_val, OP_WIDTH));
                src_A  <= var_A;
                src_B  <= var_B;
                
                wait for CLK_PERIOD * 2;
                
            end loop;
        end loop;
        rst <= '1';
        wait for CLK_PERIOD * 2;
        rst <= '0';

        wait;
    end process;

end Behavioral;