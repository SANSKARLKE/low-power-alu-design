library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.alu_pkg.ALL;

entity logic_unit is
    Port (
        op_sel  : in  std_logic_vector(OP_WIDTH-1 downto 0);
        in_A    : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        in_B    : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        log_out : out std_logic_vector(DATA_WIDTH-1 downto 0)
    );
end logic_unit;

architecture Behavioral of logic_unit is
begin
    process(op_sel, in_A, in_B)
        variable v_and, v_or, v_xor, v_not : std_logic_vector(DATA_WIDTH-1 downto 0);
    begin
        v_and := in_A and in_B;
        v_or  := in_A or in_B;
        v_xor := in_A xor in_B;
        v_not := not in_A;

        case op_sel is
            when OP_AND  => log_out <= v_and;
            when OP_OR   => log_out <= v_or;
            when OP_XOR  => log_out <= v_xor;
            when OP_NOT  => log_out <= v_not;
            when others  => log_out <= (others => '0');
        end case;
    end process;
end Behavioral;