library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity top_alu is
    Port (
        clk       : in  std_logic;
        rst       : in  std_logic;
        opcode    : in  std_logic_vector(OP_WIDTH-1 downto 0);
        src_A     : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        src_B     : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        alu_out   : out std_logic_vector(DATA_WIDTH-1 downto 0);
        alu_flags : out std_logic_vector(7 downto 0)
    );
end top_alu;

architecture Structural of top_alu is
    signal reg_A, reg_B : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal reg_op       : std_logic_vector(OP_WIDTH-1 downto 0);
    signal out_comb     : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal flags_comb   : std_logic_vector(7 downto 0);
    signal arith_w, log_w, shift_w : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal c_out, o_out            : std_logic;
    attribute keep_hierarchy : string;
    attribute keep_hierarchy of U_ARITH : label is "true";
    attribute keep_hierarchy of U_LOGIC : label is "true";
    attribute keep_hierarchy of U_SHIFT : label is "true";
begin

    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                reg_A  <= (others => '0');
                reg_B  <= (others => '0');
                reg_op <= (others => '0');
            else
                reg_A  <= src_A;
                reg_B  <= src_B;
                reg_op <= opcode;
            end if;
        end if;
    end process;
    U_ARITH: entity work.arith_unit 
        port map (op_sel => reg_op, in_A => reg_A, in_B => reg_B, arith_out => arith_w, carry_out => c_out, over_out => o_out);

    U_LOGIC: entity work.logic_unit 
        port map (op_sel => reg_op, in_A => reg_A, in_B => reg_B, log_out => log_w);

    U_SHIFT: entity work.shift_unit 
        port map (op_sel => reg_op, in_A => reg_A, in_B => reg_B, shift_out => shift_w);
    process(reg_op, reg_A, reg_B, arith_w, log_w, shift_w, c_out, o_out)
        variable v_out   : std_logic_vector(DATA_WIDTH-1 downto 0);
        variable v_flags : std_logic_vector(7 downto 0);
    begin
        v_out   := (others => '0');
        v_flags := (others => '0');

        case reg_op(3 downto 2) is
            when "00" => v_out := arith_w; v_flags(0) := c_out; v_flags(1) := o_out;
            when "01" => v_out := log_w;
            when "10" => v_out := shift_w;
            when "11" =>
                case reg_op is
                    when OP_SLT  => if signed(reg_A) < signed(reg_B) then v_out(0) := '1'; end if;
                    when OP_SLTU => if unsigned(reg_A) < unsigned(reg_B) then v_out(0) := '1'; end if;
                    when OP_SEQ  => if reg_A = reg_B then v_out(0) := '1'; end if;
                    when OP_SNE  => if reg_A /= reg_B then v_out(0) := '1'; end if;
                    when others  => null;
                end case;
            when others => null;
        end case;

        if v_out = x"00000000" then v_flags(2) := '1'; end if;
        v_flags(3) := v_out(DATA_WIDTH-1);

        out_comb   <= v_out;
        flags_comb <= v_flags;
    end process;
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                alu_out   <= (others => '0');
                alu_flags <= (others => '0');
            else
                alu_out   <= out_comb;
                alu_flags <= flags_comb;
            end if;
        end if;
    end process;
end Structural;