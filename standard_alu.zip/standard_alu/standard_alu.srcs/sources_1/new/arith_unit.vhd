library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity arith_unit is
    Port (
        op_sel    : in  std_logic_vector(OP_WIDTH-1 downto 0);
        in_A      : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        in_B      : in  std_logic_vector(DATA_WIDTH-1 downto 0);
        arith_out : out std_logic_vector(DATA_WIDTH-1 downto 0);
        carry_out : out std_logic;
        over_out  : out std_logic
    );
end arith_unit;

architecture Behavioral of arith_unit is
begin
    process(op_sel, in_A, in_B)
        variable sum_ext : unsigned(DATA_WIDTH downto 0);
        variable sub_ext : unsigned(DATA_WIDTH downto 0);
        variable mul_ext : unsigned((DATA_WIDTH*2)-1 downto 0);
    begin
        sum_ext := unsigned('0' & in_A) + unsigned('0' & in_B);
        sub_ext := unsigned('0' & in_A) - unsigned('0' & in_B);
        mul_ext := unsigned(in_A) * unsigned(in_B);
        case op_sel is
            when OP_ADD =>
                arith_out <= std_logic_vector(sum_ext(DATA_WIDTH-1 downto 0));
                carry_out <= sum_ext(DATA_WIDTH);
                over_out  <= (in_A(31) xor sum_ext(31)) and (in_B(31) xor sum_ext(31)) and not(in_A(31) xor in_B(31));
            when OP_SUB =>
                arith_out <= std_logic_vector(sub_ext(DATA_WIDTH-1 downto 0));
                carry_out <= sub_ext(DATA_WIDTH);
                over_out  <= (in_A(31) xor sub_ext(31)) and (not(in_B(31)) xor sub_ext(31)) and (in_A(31) xor in_B(31));
            when OP_MUL =>
                arith_out <= std_logic_vector(mul_ext(DATA_WIDTH-1 downto 0));
                carry_out <= '0';
                over_out  <= '0';
            when OP_INC =>
                arith_out <= std_logic_vector(unsigned(in_A) + 1);
                
                if in_A = x"FFFFFFFF" then
                    carry_out <= '1';
                else
                    carry_out <= '0';
                end if;
                
                over_out  <= '0';
            when others =>
                arith_out <= (others => '0');
                carry_out <= '0';
                over_out  <= '0';
        end case;
    end process;
end Behavioral;